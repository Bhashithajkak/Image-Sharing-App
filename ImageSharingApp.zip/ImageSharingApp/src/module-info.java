module Image_Sharing_App {
	requires java.desktop;
}